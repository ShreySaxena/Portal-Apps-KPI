package config;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

import executionEngine.DriverScript;
import utility.Log;

import static executionEngine.DriverScript.OR;

 
public class ActionKeywords {
	 
	public static WebDriver driver;

    public static void openBrowser(String object, String data) throws IOException
    {		
    	try{
    		if(data.equals("InternetExplorer"))
    		{
	DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
	capabilities.setCapability("requireWindowFocus", true);
	System.setProperty("webdriver.ie.driver", "C:\\Users\\katiyara\\Downloads\\IEDriverServer_x64_2.53.1\\IEDriverserver.exe");
    driver=new InternetExplorerDriver(capabilities);
    Log.info("Opening Browser");
    	}
    		else if (data.equals("chrome"))
    		{
    			Log.info("KPI application is compatible with IE only ");
    		}
    	int implicitWaitTime=(10);
		driver.manage().timeouts().implicitlyWait(implicitWaitTime, TimeUnit.SECONDS);
		capture_screenshot(object);}
    	catch (Exception e)
    	{
    		
    		capture_screenshot(object);
    Log.error("Not able to open Browser --- " + e.getMessage());
    DriverScript.bResult = false;
    
	}
    }
    public static void navigate(String object, String data) throws IOException{	
	try{
		Log.info("Navigating to URL");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get(data);
		capture_screenshot(object);
	}catch(Exception e){
		capture_screenshot(object);
		Log.info("Not able to navigate --- " + e.getMessage());
		DriverScript.bResult = false;
		}
	}

	public static void click(String object, String data) throws IOException{
	try{
		Log.info("Clicking on Webelement "+ object);
		driver.findElement(By.xpath(OR.getProperty(object))).click();
		capture_screenshot(object);
	 }catch(Exception e){
		 capture_screenshot(object);
			Log.error("Not able to click --- " + e.getMessage());
			DriverScript.bResult = false;
			
     	}
	}
	public static void input(String object, String data) throws IOException{
	try{
		Log.info("Entering the text "+ object);
		driver.findElement(By.xpath(OR.getProperty(object))).click();
		driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(data);
		capture_screenshot(object);
	 }catch(Exception e){
		 capture_screenshot(object);
		 Log.error("Not able to enter " +object+ e.getMessage());
		 DriverScript.bResult = false;
	 	}
	}
	
	public static void get_text(String object, String data) throws IOException{
	try{
		Log.info("Entering the text "+ object);
		  String text= driver.findElement(By.xpath(OR.getProperty(object))).getText();
		  capture_screenshot(object);
	 }
	catch(Exception e){
		capture_screenshot(object);	
		 Log.error("NUnable to fetch data from " +object+ e.getMessage());
		 DriverScript.bResult = false;
	 	}
	}
	
	public static void compare_sample_value(String object, String data) throws IOException
	{
		
		  String JDBC_DRIVER = "oracle.jdbc.driver.OracleDriver";  
			    String DB_URL = "jdbc:oracle:thin:@drmsdb01:1521:devkpi02";
			    String USER = "KPI2_user";
			   String PASS = "devkpi02";
			   Connection conn = null;
			   Statement stmt = null;
			   try{
			      Class.forName(JDBC_DRIVER);
			      conn = DriverManager.getConnection(DB_URL, USER, PASS);
			     stmt = conn.createStatement();
			   //  String sql = "select sample_value from chain_dtl where stat_id in ('WBALTFES') and dttm_seq_id in (select dttm_seq_id from time_period where sample_dttm = '07-Jun-2016' and time_frame='DA')";
			      ResultSet rs = stmt.executeQuery(data);
			      while(rs.next()){
			    	String  sample_value = rs.getString(1);								        
			         System.out.print("Sample value: "+sample_value);
			      String   s= driver.findElement(By.xpath((OR.getProperty(object)))).getText();
			  	String   ns=s.replaceAll(",", "");
			  	String S=  ns.substring(1);
			  	   System.out.println(S);
			           
			      }
			      rs.close();
			   }
			   catch(SQLException se){
			     se.printStackTrace();
			   }
			   catch(Exception e){
			       e.printStackTrace();
			   }
			   finally{
			     try{
			         if(stmt!=null)
			            conn.close();
			      }catch(SQLException se){
			      }try{
			         if(conn!=null)
			            conn.close();
			      }catch(SQLException se){
			         se.printStackTrace();
			      }
			   }
		}
			
	

	public static void waitFor(String object, String data) throws Exception{
	try{
		Log.info("Wait for 5 seconds");
		Thread.sleep(5000);
		DriverScript.bResult=true;
	 }catch(Exception e){
		 capture_screenshot(object);
		 Log.error("Not able to Wait --- " + e.getMessage());
		 DriverScript.bResult = false;
     	}
	}
	
	public static void select_dropdown(String object, String data) throws Exception
	{
		try
		{ 
			
			if(object.equals("drpdwn_Timeframe"))
			{
				
				Select dropdown= new Select(driver.findElement(By.name((OR.getProperty(object)))));
				dropdown.selectByVisibleText(data);
				DriverScript.bResult=true;
				Log.info("Timeframe "+ data+ "is selected");
				capture_screenshot(object);
			}
			
			else if (object.equals("drpdwn_Stores"))				
			{
				Select dropdown= new Select(driver.findElement(By.name((OR.getProperty(object)))));
				dropdown.selectByVisibleText(data);
				DriverScript.bResult=true;
				Log.info("Stores "+ data+ "is selected");
				capture_screenshot(object);
		}
			else if (object.equals("drpdwn_Location"))
			{
				Select dropdown= new Select(driver.findElement(By.name((OR.getProperty(object)))));
				dropdown.selectByIndex(Integer.parseInt(data));
				DriverScript.bResult=true;
				Log.info("location "+ data+ "is selected");
				capture_screenshot(object);
			}

			else if (object.equals("drpdwn_Day"))
			{
				Select dropdown= new Select(driver.findElement(By.name((OR.getProperty(object)))));
				dropdown.selectByVisibleText(data);
				DriverScript.bResult=true;
				Log.info("Compare Type "+ data+ "is selected");
				capture_screenshot(object);
			}
			else if(object.equals("drpdwn_Summary"))
			{
				Select dropdown= new Select(driver.findElement(By.name((OR.getProperty(object)))));
				dropdown.selectByVisibleText(data); 
				DriverScript.bResult=true;
				Log.info("Summary Type "+ data+ "is selected");
				capture_screenshot(object);
			}
			else if(object.equals("drpdwn_Department"))
			{
				Select dropdown= new Select(driver.findElement(By.name((OR.getProperty(object)))));
				dropdown.selectByIndex(Integer.parseInt(data));
				DriverScript.bResult=true;
				Log.info("Department Type "+ data+ "is selected");
				capture_screenshot(object);
			}
		
		}
				
			catch(Exception e){
				 Log.error("Dropdowns are not working " + e.getMessage());
				 DriverScript.bResult = false;
				 capture_screenshot(object);
				 capture_screenshot(object);
	
		}
	}

	public static void verify_links(String object, String data) throws IOException
	{
		
		try
	{
			 List<WebElement> linkElements = driver.findElements(By.linkText(OR.getProperty(object)));
		        String[] linkTexts = new String[linkElements.size()];
		        int i = 0;
		        for (WebElement e : linkElements) {
		            linkTexts[i] = e.getText();
		            i++;
		        }
		        //test each link
		        for (String t : linkTexts) {
		            driver.findElement(By.linkText(OR.getProperty(object))).click();
		            if (driver.findElement(By.linkText(OR.getProperty(object))).isEnabled()) {
		                Log.info("\"" + t + "\""
		                        + " is not working");
		            } else {
		                Log.info("\"" + t + "\""
		                        + " is working.");
		            }
		            driver.navigate().back();
	}
	}
	catch(Exception e)
	{
		Log.info("following links are not working"+ object +e.getMessage());
		DriverScript.bResult=false;
		capture_screenshot(object);
	}
	}
	
	public static void closeBrowser(String object) throws IOException{
	try{
		Log.info("Closing the browser");
		driver.quit();
	 }catch(Exception e){
		 Log.error("Not able to Close the Browser --- " + e.getMessage());
		 DriverScript.bResult = false;
		 capture_screenshot(object);
     	}
	}
	public static void capture_screenshot(String object) throws IOException
	{
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile, new File("C:\\Users\\549358\\workspace\\New\\test-output\\screenshots"+ object  +".png"));	
	}
	
}

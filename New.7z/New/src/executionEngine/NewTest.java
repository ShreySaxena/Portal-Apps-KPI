package executionEngine;

import org.testng.annotations.Test;

import com.gargoylesoftware.htmlunit.javascript.host.Set;
import com.sun.jna.IntegerType;

import config.Constants;
import utility.Log;

import org.testng.annotations.BeforeTest;

import static executionEngine.DriverScript.OR;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
public class NewTest {
	public static WebDriver driver;
	static  String s;
	static String ns;
	   static String sample_value;
	   static String S;
  
  public static void main(String args[]) {
	 
	  try{
		  beforeTest();
		  Actions action = new Actions(driver);
		  Log.info("Navigating to URL");
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.get("http://drmsap01.walgreens.com:8080/SNETMWBWeb/servlet/walgreens.mwb.servlet.MWBServlet/Page?pg=R&area=S&type=S&dtl=C&dv=0&est=&tabid=2&legal=true");
	       driver.findElement(By.xpath(".//html/body/form/table/tbody/tr[3]/td[1]/table/tbody/tr[2]/td[2]/input")).sendKeys("dstrops");
	       driver.findElement(By.xpath(".//html/body/form/table/tbody/tr[3]/td[1]/table/tbody/tr[3]/td[2]/input")).sendKeys("pass4word");
	       Log.info("Entering username & pssword");
	       driver.findElement(By.xpath(".//html/body/form/table/tbody/tr[3]/td[1]/table/tbody/tr[4]/td/input")).click();
	  Log.info("Logging in");
	  driver.findElement(By.xpath(".//html/body/div[2]/table/tbody/tr/td/div[2]/table/tbody/tr/td/div/table/tbody/tr[2]/td/div/table/tbody/tr/td/table/tbody/tr[1]/td[2]/a")).click();
	 
	  Log.info(driver.getTitle());
	driver.navigate().to("http://drmsap01.walgreens.com:8080/SNETMWBWeb/servlet/walgreens.mwb.servlet.MWBServlet/Page?est=E&rloc=C&area=S&type=T&cmp=dy&legal=true&ar=corporateuser&usrtype=C&pg=R&tabid=2&dept=F&sup=Y&dtl=C&id=307&tf=DA");
	
	 
	 Select dropdown= new Select(driver.findElement(By.name(("dtl"))));
		dropdown.selectByIndex(0);
		 Select dropdown1= new Select(driver.findElement(By.name(("est"))));
				 dropdown1.selectByVisibleText("All");
				driver.findElement(By.name("da")).click();
			driver.findElement(By.name("da")).sendKeys(Keys.chord(Keys.CONTROL, "a"),"90" + "\n");	

						
//				 Select dropdown2= new Select(driver.findElement(By.name(("dept"))));
//					dropdown2.selectByIndex(1);
						
			
		Thread.sleep(2000);		
	   s= driver.findElement(By.xpath(".//html/body/div[2]/table/tbody/tr/td/div[2]/table/tbody/tr/td/div/table/tbody/tr[2]/td/div/table/tbody/tr/td/table/tbody/tr[51]/td[2]")).getText();
	   ns=s.replaceAll(",", "");
	S=  ns.substring(1);
	   System.out.println(S);	
		db();
		compare();
			
			
	  }
	  
	  //---------------------------------------------------------------------------------	
	//  int rowcount = driver.findElements(By.id("datatable")).size();
//	  				WebElement table=  driver.findElement(By.id("datatable"));
//	  	List <WebElement> rows= table.findElements(By.tagName("tr"));
//	  			int rowcount1= rows.size();
//	  				
//	  	  System.out.println(rowcount1);
//	    for (int rnum=0;rnum<rowcount1; rnum++)
//	    {
//	  	  List <WebElement> cols=rows.get(rnum).findElements(By.tagName("td"));
//	  	 
//	    
//	    for (int cnum=0; cnum< cols.size(); cnum++)
//	   {
//	  	
//	    	if (cols.get(cnum).getText()=="Tue, Jun 07, 2016")
//	    	{
//	    		System.out.println("true");
//	    	}
//	   
//	  	  }
//	  	  System.out.println("Number of Columns" +cols.size());
//	  
//	    }
//	    }

			
//-----------------------------------------------------------------------------------				
//			String s= driver.findElement(By.id("datatable")).getText();
//		 System.out.println(s);
//			
//--------------------------------------------------------------------------------  
				
	    	catch (Exception e)
	    	{
	    		e.printStackTrace();
	    		
	    
		}
	    }
  
  public static void db() {
	    String JDBC_DRIVER = "oracle.jdbc.driver.OracleDriver";  
	    String DB_URL = "jdbc:oracle:thin:@drmsdb01:1521:devkpi02";
	    String USER = "KPI2_user";
	   String PASS = "devkpi02";
	   Connection conn = null;
	   Statement stmt = null;
	   try{
	      Class.forName("oracle.jdbc.driver.OracleDriver");
	      conn = DriverManager.getConnection(DB_URL, USER, PASS);
	     stmt = conn.createStatement();
	     Log.info("Connecting to database");
	     
	     String sql = "select sample_value from chain_dtl where stat_id in ('WBALTFES') and dttm_seq_id in (select dttm_seq_id from time_period where sample_dttm = '07-Jun-2016' and time_frame='DA')";
	     Log.info("Executing the query"+ sql);
	     ResultSet rs = stmt.executeQuery(sql);
	      while(rs.next()){
	    	  sample_value = rs.getString(1);								        
//	        int sample_val=Integer.parseInt(sample_value);
//	        
//	        int a = (int) Math.round(sample_val);
//	         //Display values
	         System.out.print("Sample value: "+sample_value);
	         
	         
	      }
	      rs.close();
	   }catch(SQLException se){
	     se.printStackTrace();
	   }catch(Exception e){
	       e.printStackTrace();
	   }finally{
	     try{
	         if(stmt!=null)
	            conn.close();
	      }catch(SQLException se){
	      }try{
	         if(conn!=null)
	            conn.close();
	      }catch(SQLException se){
	         se.printStackTrace();
	      }
	   } System.out.println();
	   System.out.println("connection close");
	}
  public static void compare()
  {
	  
	 if(sample_value.equals(S))
	 {
		 System.out.println("total front end sales matching");
	 }
	 else 
	 {
		 System.out.println("fail");
	 }
  }
	
  
  
  public static void beforeTest() throws ClassNotFoundException, SQLException {
	  try{
		  DOMConfigurator.configure("log4j.xml");
		  DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
			capabilities.setCapability("requireWindowFocus", true);
			System.setProperty("webdriver.ie.driver", "C:\\Users\\katiyara\\Downloads\\IEDriverServer_x64_2.53.1\\IEDriverserver.exe");
		    driver=new InternetExplorerDriver(capabilities);
		   	int implicitWaitTime=(10);
				driver.manage().timeouts().implicitlyWait(implicitWaitTime, TimeUnit.SECONDS);
				  
		
//				    String DB_URL = "jdbc:oracle:thin:@drmsdb01:1521:devkpi02";
//				    String USER = "kpi_user";
//				   String PASS = "devkpi02";
//				   Connection conn = null;
//				   Statement stmt = null;
//				   Class.forName("oracle.jdbc.driver.OracleDriver");
//				      conn = DriverManager.getConnection(DB_URL, USER, PASS);
//				     stmt = conn.createStatement();
//				     String sql = "select * from chain_dtl where stat_id in ('WBALTFES') and dttm_seq_id in (select dttm_seq_id from time_period where sample_dttm = '07-Jun-2016' and time_frame='DA')";
//				      ResultSet rs = stmt.executeQuery(sql);
//				      System.out.println(rs);
	  }
		    	catch (Exception e)
		    	{		    		
		 		
		    		 Log.info("Not able to open Browser --- " + e.getMessage());
			}
		    
  }

  @AfterTest
  public void afterTest() {
  }

}

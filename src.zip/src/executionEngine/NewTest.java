package executionEngine;

import org.testng.annotations.Test;

import config.Constants;
import utility.Log;

import org.testng.annotations.BeforeTest;
 
import static executionEngine.DriverScript.OR;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;




public class NewTest {
	public static WebDriver driver;
  @Test
  public void f() {
	  try{
		  
		  Log.info("Navigating to URL");
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.get("http://drmsap01.walgreens.com:8080/SNETMWBWeb/servlet/walgreens.mwb.servlet.MWBServlet/Page?pg=R&area=S&type=S&dtl=C&dv=0&est=&tabid=2&legal=true");
	       driver.findElement(By.xpath(".//html/body/form/table/tbody/tr[3]/td[1]/table/tbody/tr[2]/td[2]/input")).sendKeys("dstrops");
	       driver.findElement(By.xpath(".//html/body/form/table/tbody/tr[3]/td[1]/table/tbody/tr[3]/td[2]/input")).sendKeys("pass4word");
	       Log.info("Entering username & pssword");
	       driver.findElement(By.xpath(".//html/body/form/table/tbody/tr[3]/td[1]/table/tbody/tr[4]/td/input")).click();
	  Log.info("Logging in");
	  driver.findElement(By.xpath(".//html/body/div[2]/table/tbody/tr/td/div[2]/table/tbody/tr/td/div/table/tbody/tr[2]/td/div/table/tbody/tr/td/table/tbody/tr[1]/td[2]/a")).click();
	 
	  Log.info(driver.getTitle());
	 driver.navigate().to("http://drmsap01.walgreens.com:8080/SNETMWBWeb/servlet/walgreens.mwb.servlet.MWBServlet/Page?est=E&rloc=C&area=S&type=T&cmp=dy&legal=true&ar=corporateuser&usrtype=C&pg=R&tabid=2&dept=F&sup=Y&dtl=C&id=307&tf=DA");
	  Select dropdown= new Select(driver.findElement(By.name(("est"))));
		dropdown.selectByVisibleText("All");
		driver.findElement(By.xpath(".//html/body/div[2]/table/tbody/tr/td/div[1]/div[1]/table/tbody/tr[2]/td[6]/input")).sendKeys("60");
		   String dbUrl = "jdbc:oracle:thin:@drmsdb01:1521:devkpi02";					
			String username = "KPI2_user";	
			String password = "devkpi02";				
			String query = "select * from chain_dtl where stat_id in ('WBALTFES') and dttm_seq_id in (select dttm_seq_id from time_period where sample_dttm = '06-Jun-2016' and time_frame='DA')";	            
    	    Class.forName("oracle.jdbc.driver.OracleDriver");			       
      		Connection con = DriverManager.getConnection(dbUrl,username,password);
     		 Statement stmt = con.createStatement();					   
  			 ResultSet rs= stmt.executeQuery(query);
  			 System.out.println(rs);
  			
 			con.close();			

	  
	  
	  }
	    	catch (Exception e)
	    	{
	    		
	    		
	   
	    
		}
	    }
  
  @BeforeTest
  public void beforeTest() {
	  try{
		  DOMConfigurator.configure("log4j.xml");
		  DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
			capabilities.setCapability("requireWindowFocus", true);
			System.setProperty("webdriver.ie.driver", "C:\\Users\\katiyara\\Downloads\\IEDriverServer_x64_2.53.1\\IEDriverserver.exe");
		    driver=new InternetExplorerDriver(capabilities);
		   	int implicitWaitTime=(10);
				driver.manage().timeouts().implicitlyWait(implicitWaitTime, TimeUnit.SECONDS);	}
		    	catch (Exception e)
		    	{		    		
		    Log.info("Not able to open Browser --- " + e.getMessage());
		    DriverScript.bResult = false;
		    
			}
		    
  }

  @AfterTest
  public void afterTest() {
  }

}

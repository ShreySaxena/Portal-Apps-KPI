package config;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

import executionEngine.DriverScript;
import utility.Log;

import static executionEngine.DriverScript.OR;

 
public class ActionKeywords {
	 
	public static WebDriver driver;

    public static void openBrowser(String object, String data) throws IOException
    {		
    	try{
    		if(data.equals("InternetExplorer"))
    		{
	DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
	capabilities.setCapability("requireWindowFocus", true);
	System.setProperty("webdriver.ie.driver", "C:\\Users\\Workspace\\KPI\\JARS\\IEDriverServer_x64_2.53.1\\IEDriverserver.exe");
    driver=new InternetExplorerDriver(capabilities);
    Log.info("Opening Browser");
    	}
    		else if (data.equals("chrome"))
    		{
    			Log.info("KPI application is compatible with IE only ");
    		}
    	int implicitWaitTime=(10);
		driver.manage().timeouts().implicitlyWait(implicitWaitTime, TimeUnit.SECONDS);	}
    	catch (Exception e)
    	{
    		
    		capture_screenshot(object);
    Log.info("Not able to open Browser --- " + e.getMessage());
    DriverScript.bResult = false;
    
	}
    }
    public static void navigate(String object, String data) throws IOException{	
	try{
		Log.info("Navigating to URL");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get(Constants.URL);
	}catch(Exception e){
		capture_screenshot(object);
		Log.info("Not able to navigate --- " + e.getMessage());
		DriverScript.bResult = false;
		}
	}

	public static void click(String object, String data) throws IOException{
	try{
		Log.info("Clicking on Webelement "+ object);
		driver.findElement(By.xpath(OR.getProperty(object))).click();
	 }catch(Exception e){
		 capture_screenshot(object);
			Log.error("Not able to click --- " + e.getMessage());
			DriverScript.bResult = false;
     	}
	}
	public static void input(String object, String data) throws IOException{
	try{
		Log.info("Entering the text "+ object);
		driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(data);
	 }catch(Exception e){
		 capture_screenshot(object);
		 Log.error("Not able to enter " +object+ e.getMessage());
		 DriverScript.bResult = false;
	 	}
	}
	
	public static void get_text(String object, String data) throws IOException{
	try{
		Log.info("Entering the text "+ object);
		  String text= driver.findElement(By.xpath(OR.getProperty(object))).getText();
	 }
	catch(Exception e){
		capture_screenshot(object);	
		 Log.error("NUnable to fetch data from " +object+ e.getMessage());
		 DriverScript.bResult = false;
	 	}
	}
	
	public static void connect_db(String object, String data) throws IOException
	{
		try
		{
	            String dbUrl = "jdbc:oracle:thin:@drmsdb01:1521:devkpi02";					
				String username = "KPI2_user";	
				String password = "devkpi02";				
				String query = "select * from store_dtl_sales where store_nbr=13";	            
	     	    Class.forName("oracle.jdbc.driver.OracleDriver");			       
	       		Connection con = DriverManager.getConnection(dbUrl,username,password);
	      		 Statement stmt = con.createStatement();					   
	   			 ResultSet rs= stmt.executeQuery(query);							
	   			
	  			con.close();			

		}
		catch (Exception e)
		{
			capture_screenshot(object);
			Log.error("Database connection unsuccessful" +object+ e.getMessage());
			DriverScript.bResult = false;
		}
	}
	

	

	public static void waitFor(String object, String data) throws Exception{
	try{
		Log.info("Wait for 5 seconds");
		Thread.sleep(5000);
	 }catch(Exception e){
		 capture_screenshot(object);
		 Log.error("Not able to Wait --- " + e.getMessage());
		 DriverScript.bResult = false;
     	}
	}
	
	public static void select_dropdown(String object, String data) throws Exception
	{
		try
		{
			if(object=="drpdwn_Timeframe")
			{
				Select dropdown= new Select(driver.findElement(By.xpath((OR.getProperty(object)))));
				dropdown.selectByVisibleText(data);
				DriverScript.bResult=true;
				Log.info("Timeframe "+ data+ "is selected");
			}
			
			else if (object=="drpdown_Stores")				
			{
				Select dropdown= new Select(driver.findElement(By.xpath((OR.getProperty(object)))));
				dropdown.selectByVisibleText(data);
				DriverScript.bResult=true;
				Log.info("Stores "+ data+ "is selected");
		}
			else if (object=="drpdwn_Locations")
			{
				Select dropdown= new Select(driver.findElement(By.xpath((OR.getProperty(object)))));
				dropdown.selectByVisibleText(data);
				DriverScript.bResult=true;
				Log.info("location "+ data+ "is selected");
			}
//			else if (object=="txtbx_Number")
//			{
//				driver.findElement(By.xpath(object)).sendKeys(data);
//				DriverScript.bResult=true;
//				Log.info("Location number "+ data+ "is entered");
//			}
			else if (object=="drpdwn_Day")
			{
				Select dropdown= new Select(driver.findElement(By.xpath((OR.getProperty(object)))));
				dropdown.selectByVisibleText(data);
				DriverScript.bResult=true;
				Log.info("Compare Type "+ data+ "is selected");
			}
			else if(object=="drpdwn_Summary")
			{
				Select dropdown= new Select(driver.findElement(By.xpath((OR.getProperty(object)))));
				dropdown.selectByVisibleText(data); 
				DriverScript.bResult=true;
				Log.info("Summary Type "+ data+ "is selected");
			}
		
		}
				
			catch(Exception e){
				 Log.error("Dropdowns are not working " + e.getMessage());
				 DriverScript.bResult = false;
				 capture_screenshot(object);
	
		}
	}
	
//	{
//		try
//		{
//			if (object=="drpdwn_Timeframe")
//			{
//				Log.info("Validating Timeframe dropdown");
//				String[] tf = {"Yesterday", "Last Week", "Last Period", "Last Month", "Month To Date"}; 
//		    	WebElement dropdown =  driver.findElement(By.xpath(OR.getProperty(object)));
//		    	        Select select = new Select(dropdown);  
//		    	        List<WebElement> options = select.getOptions();  
//		    	        for(WebElement we:options)  
//		    	        {  
//		    	         for (int i=0; i<tf.length; i++){
//		    	             if (we.getText().equals(tf[i])){
//		    	            DriverScript.bResult=true;
//		    	             } 
//		    	           }
//			}
//			}
//			else if (object=="drpdwn_Stores")
//			 {	
//		    	String[] tf = {"Established", "Non-Established", "Comparable", "Non-Comparable", "All", "Well Experience"}; 
//		    	WebElement dropdown = driver.findElement(By.xpath(OR.getProperty(object)));  
//		    	       Select select = new Select(dropdown);  
//		    	        List<WebElement> options = select.getOptions();  
//		    	        for(WebElement we:options)  
//		    	        {  
//		    	         for (int i=0; i<tf.length; i++){
//		    	             if (we.getText().equals(tf[i])){
//		    	            	 DriverScript.bResult=true;
//		    	             } 
//		    	           }
//		    }
//				
//		}
//			else if (object=="drpdwn_Locations")
//			 {  	
//		    	String[] tf = {"Store", "District", "Area", "Region", "Operation", "Chain"}; 
//		    	WebElement dropdown = driver.findElement(By.xpath(OR.getProperty(object)));  
//		    	        Select select = new Select(dropdown);  
//		    	        List<WebElement> options = select.getOptions();  
//		    	       for(WebElement we:options)  
//		    	        {  
//		    	         for (int i=0; i<tf.length; i++){
//		    	             if (we.getText().equals(tf[i])){
//		    	            	 DriverScript.bResult=true;
//		    	             } 
//		    	           }
//		    	        }
//			 }
//			else if(object=="drpdwn_Day")
//			  {   	
//		    	String[] tf = {"By Day", "By Date"}; 
//		    	WebElement dropdown = driver.findElement(By.xpath(OR.getProperty(object)));  
//		    	        Select select = new Select(dropdown);  
//		    	        List<WebElement> options = select.getOptions();  
//		    	        for(WebElement we:options)  
//		    	        {  
//		    	         for (int i=0; i<tf.length; i++){
//		    	             if (we.getText().equals(tf[i])){
//		    	            	 DriverScript.bResult=true;
//		    	             } 
//		    	           }
//		    }
//		    }
//			else if (object=="drpdwn_Summary")
//			{   	
//		    	String[] tf = {"Trend", "Rank ", "Store Rank", "District Rank","Area Rank","Region Rank","Summary", "Exception KPI", "Holiday"}; 
//		    	WebElement dropdown = driver.findElement(By.xpath(OR.getProperty(object)));  
//		    	        Select select = new Select(dropdown);  
//		    	        List<WebElement> options = select.getOptions();  
//		    	        for(WebElement we:options)  
//		    	        {  
//		    	         for (int i=0; i<tf.length; i++){
//		    	             if (we.getText().equals(tf[i])){
//		    	            	 DriverScript.bResult=true;
//		    	             } 
//		    	           }
//		    }
//		    }
//		}
//		
//		catch(Exception e)
//		{
//			 Log.error("Drop Downs are not working as expected " + e.getMessage());
//			 DriverScript.bResult = false;
//		}
//		}
	public static void verify_links(String object, String data) throws IOException
	{
		
		try
	{
			 List<WebElement> linkElements = driver.findElements(By.linkText(OR.getProperty(object)));
		        String[] linkTexts = new String[linkElements.size()];
		        int i = 0;
		        for (WebElement e : linkElements) {
		            linkTexts[i] = e.getText();
		            i++;
		        }
		        //test each link
		        for (String t : linkTexts) {
		            driver.findElement(By.linkText(OR.getProperty(object))).click();
		            if (driver.findElement(By.linkText(OR.getProperty(object))).isEnabled()) {
		                Log.info("\"" + t + "\""
		                        + " is not working");
		            } else {
		                Log.info("\"" + t + "\""
		                        + " is working.");
		            }
		            driver.navigate().back();
	}
	}
	catch(Exception e)
	{
		Log.info("following links are not working"+ object +e.getMessage());
		DriverScript.bResult=false;
		capture_screenshot(object);
	}
	}
	
	public static void closeBrowser(String object) throws IOException{
	try{
		Log.info("Closing the browser");
		driver.quit();
	 }catch(Exception e){
		 Log.error("Not able to Close the Browser --- " + e.getMessage());
		 DriverScript.bResult = false;
		 capture_screenshot(object);
     	}
	}
	public static void capture_screenshot(String object) throws IOException
	{
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile, new File("c:\\tmp\\screenshot"+ object  +".png"));	
	}

}
